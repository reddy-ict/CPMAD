# Generated code do not commit.
file(TO_CMAKE_PATH "C:\\Users\\umama\\Documents\\SEM 05\\CPMAD SETUP\\flutter" FLUTTER_ROOT)
file(TO_CMAKE_PATH "C:\\Users\\umama\\Documents\\SEM 05\\CPMAD SETUP\\Apps\\ecom_app\\ecom_app" PROJECT_DIR)

set(FLUTTER_VERSION "1.0.0+1" PARENT_SCOPE)
set(FLUTTER_VERSION_MAJOR 1 PARENT_SCOPE)
set(FLUTTER_VERSION_MINOR 0 PARENT_SCOPE)
set(FLUTTER_VERSION_PATCH 0 PARENT_SCOPE)
set(FLUTTER_VERSION_BUILD 1 PARENT_SCOPE)

# Environment variables to pass to tool_backend.sh
list(APPEND FLUTTER_TOOL_ENVIRONMENT
  "FLUTTER_ROOT=C:\\Users\\umama\\Documents\\SEM 05\\CPMAD SETUP\\flutter"
  "PROJECT_DIR=C:\\Users\\umama\\Documents\\SEM 05\\CPMAD SETUP\\Apps\\ecom_app\\ecom_app"
  "FLUTTER_ROOT=C:\\Users\\umama\\Documents\\SEM 05\\CPMAD SETUP\\flutter"
  "FLUTTER_EPHEMERAL_DIR=C:\\Users\\umama\\Documents\\SEM 05\\CPMAD SETUP\\Apps\\ecom_app\\ecom_app\\windows\\flutter\\ephemeral"
  "PROJECT_DIR=C:\\Users\\umama\\Documents\\SEM 05\\CPMAD SETUP\\Apps\\ecom_app\\ecom_app"
  "FLUTTER_TARGET=C:\\Users\\umama\\Documents\\SEM 05\\CPMAD SETUP\\Apps\\ecom_app\\ecom_app\\lib\\main.dart"
  "DART_DEFINES=RkxVVFRFUl9WRVJTSU9OPTMuNDQuNw==,RkxVVFRFUl9DSEFOTkVMPXN0YWJsZQ==,RkxVVFRFUl9HSVRfVVJMPWh0dHBzOi8vZ2l0aHViLmNvbS9mbHV0dGVyL2ZsdXR0ZXIuZ2l0,RkxVVFRFUl9GUkFNRVdPUktfUkVWSVNJT049ODRmYzVjYmIyMg==,RkxVVFRFUl9FTkdJTkVfUkVWSVNJT049NjljOGM2MTc5Mg==,RkxVVFRFUl9EQVJUX1ZFUlNJT049My4xMi4y"
  "DART_OBFUSCATION=false"
  "TRACK_WIDGET_CREATION=true"
  "TREE_SHAKE_ICONS=false"
  "PACKAGE_CONFIG=C:\\Users\\umama\\Documents\\SEM 05\\CPMAD SETUP\\Apps\\ecom_app\\ecom_app\\.dart_tool\\package_config.json"
)
